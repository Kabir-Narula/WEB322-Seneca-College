
/******************************************************************************** 
*  BTI325 – Assignment 02 
*  
*  I declare that this assignment is my own work in accordance with Seneca's 
*  Academic Integrity Policy: 
*  
*  https://www.senecacollege.ca/about/policies/academic-integrity-policy.html 
*  
*  Name: Kabir Narula Student ID: 127962223 Date: 25 September 2023
* 
********************************************************************************/ 

const express = require("express");
const app = express();
const port = 3000; 

const legoData = require("./modules/legoSets");


legoData.initialize().then(() => {
  // Routes
  app.get("/", (req, res) => {
    res.send("Assignment 2: Kabir Narula - 127962223");
  });

  app.get("/lego/sets", async (req, res) => {
    const sets = await legoData.getAllSets();
    res.json(sets);
  });

  app.get("/lego/sets/num-demo", async (req, res) => {
    const setNum = "VP-1"; 
    try {
      const set = await legoData.getSetByNum(setNum);
      res.json(set);
    } catch (error) {
      res.status(404).send(error);
    }
  });

  app.get("/lego/sets/theme-demo", async (req, res) => {
    const theme = "Video Games"; 
    try {
      const sets = await legoData.getSetsByTheme(theme);
      res.json(sets);
    } catch (error) {
      res.status(404).send(error);
    }
  });

  // Start the server
  app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
});
